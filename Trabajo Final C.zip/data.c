#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"data.h"

// INICIALIZACION DE LA ESTRUCTURA DataSet
void dsInit(TDataset *ds)
{
	ds->nf=0;
	ds->nc=0;
	ds->nErr=0;
	ds->meta=NULL;
	ds->mat=NULL;
}

int dsLoad(TDataset *ds, const char *fileName, int header, char sep)
{
	FILE *f;
	char cabecera[1001], lineaDatos[1001];
	char *tok, separadores[10];
	int col, filas, columnas, pos, i;
	double numAux;

	// Establecer separadores para strtok
	sprintf(separadores, "%c \t\n\r", sep);

	// Abrir el fichero de datos y leer la primer línea
	f=fopen(fileName, "r");
	if(f==NULL)
	{
		printf("Error al abrir el fichero\n\n");
		exit(1);
	}
	
	// Leer dos líneas si hay cabecera, o una si no la hay
	if(header)
		fgets(cabecera, 1000, f);
	fgets(lineaDatos, 1000, f);

	// Crear las columnas del DATASET
	CrearColumnas(ds, cabecera, lineaDatos, header, separadores);

	// Recorrer todo el fichero para contar filas correctas y erroneas
	while(!feof(f))
	{
		fgets(lineaDatos, 1000, f);
		if(FilaValida(ds, lineaDatos, separadores, 1)) // modo=1
			ds->nf++;
		else
			ds->nErr++;
	}

	// Reservar memoria para los datos
	ds->mat=(double**)malloc(sizeof(double*) * ds->nf);
	if(ds->mat==NULL)
	{
		printf("ERROR de memoria en dsLoad (1)\n\n");
		exit(1);
	}
	for(i=0 ; i<ds->nf ; i++)
	{
		ds->mat[i]=(double*)malloc(sizeof(double) * ds->nc);
		if(ds->mat==NULL)
		{
			printf("ERROR de memoria en dsLoad (2): fila %d\n\n", i);
			exit(1);
		}
	}

	// Inicializar el fichero de entrada
	fseek(f, 0, SEEK_SET);
	fgets(lineaDatos, 1000, f);
	if(header)
		fgets(lineaDatos, 1000, f);
	ds->nf=1;

	// Recorrer todo el fichero para contar filas correctas y erroneas
	while(!feof(f))
	{
		fgets(lineaDatos, 1000, f);
		if(FilaValida(ds, lineaDatos, separadores, 2)) // modo=2
			ds->nf++;
	}
	fclose(f);

	return 1;
}

int  dsSaveMeta(const TDataset *ds, const char *fileName)
{
	FILE *f;
	int i, j;
	
	f=fopen(fileName, "w");
	if(f==NULL)
	{
		printf("Error al abrir fichero para escribir METADATOS\n");
		exit(1);
	}
	fprintf(f, "filas: %d\n", ds->nf);
	fprintf(f, "columnas: %d\n", ds->nc);
	for(i=0 ; i<ds->nc ; i++)
	{
		fprintf(f, "col %2d: '%s' (%s)\n", i,
		    ds->meta[i].nombre, cadenaTipo(ds->meta[i].tipo));
		switch(ds->meta[i].tipo)
		{
			case NUM:
				fprintf(f, "   # min:%f , max:%f , med:%f\n",
					ds->meta[i].min,
					ds->meta[i].max,
					(ds->meta[i].sum/ds->nf));
				break;

			case LABEL:
				fprintf(f, "   #");
				for(j=0 ; j<ds->meta[i].numValores ; j++)
					fprintf(f, " %s (%d)",
						ds->meta[i].etiquetas[j],
						ds->meta[i].repeticiones[j]);
				fprintf(f, "\n");
				break;
		}
	}
	
	fclose(f);
	return 1;
}

int  dsSaveData(const TDataset *ds, const char *fileName, int header, char sep)
{
	int numFil, numCol;
	FILE *f = fopen(fileName, "w");
	
	if(f==NULL)
	{
		printf("ERROR al abrir fichero de escritura\n\n");
		exit(0);
	}

	if(header)
	{
		for(numCol=0 ; numCol<ds->nc ; numCol++)
		{
			if(numCol>0)
			{
				fprintf(f, "%c", sep);
			}
			fprintf(f, "%s", ds->meta[numCol].nombre);
		}
		fprintf(f, "\n");
	}
	for(numFil=0 ; numFil<ds->nf ; numFil++)
	{
		for(numCol=0 ; numCol<ds->nc ; numCol++)
		{
			if(numCol>0)
			{
				fprintf(f, "%c", sep);
			}
			switch(ds->meta[numCol].tipo)
			{
				case NUM:
					fprintf(f, "%f", ds->mat[numFil][numCol]);
					break;

				case LABEL:
					fprintf(f, "%s",
					ds->meta[numCol].etiquetas[ (int)ds->mat[numFil][numCol] ]);
					break;
			}
		}
		fprintf(f, "\n");
	}
	fclose(f);
	return 1;
}

int numColumnas(char *reg, char sep)
{
	int i=0;
	int con=1;

	if(reg==NULL || reg[0]=='\0')
		return 0;

	while(reg[i]!='\0')
	{
		if(reg[i]==sep)
			con++;
		i++;
	}
	return con;
}

int validarNum(char *cad)
{
	int i, punto=0;
	
	if(cad[0]=='-' || cad[0]=='+')
		i=1;
	else
		i=0;
	while(cad[i]!='\0')
	{
		if(cad[i]=='.')
		{
			punto++;
			if(punto>1)
				return 0;
		}
		else if(cad[i]<'0' || cad[i]>'9')
			return 0;
		i++;
	}
	return 1;
}

TYPE ObtenerTipo(char *cad)
{
	if(validarNum(cad))
		return NUM;
	//if(validarFecha(cad))
	//	return DATE;
	return LABEL;
}

char *cadenaTipo(TYPE t)
{
	switch(t)
	{
		case NUM:
			return "NUMERO";
			break;
		case LABEL:
			return "LABEL";
			break;
		//case DATE:
		//	return "FECHA";
		//	break;
		default:
			return "[type??]";
			break;
	}
}

int IndexOfStr(char **arr, int n, const char *val)
{
	int i;
	
	for(i=0 ; i<n ; i++)
		if(strcmp(arr[i], val)==0)
			return i;
	return -1;
}

void CrearColumnas(TDataset *ds, char *cabecera, char *lineaDatos, int header, char *separadores)
{
	int i, numCol= numColumnas(lineaDatos, separadores[0]);
	char *tok;

	if(numCol==0 || (header && numCol!=numColumnas(cabecera, separadores[0])))
	{
		printf("ERROR al leer el fichero de datos\n\n");
		exit(0);
	}

	ds->meta=(TColumn*)malloc(sizeof(TColumn) * numCol);
	if(ds->meta==NULL)
	{
		printf("ERROR de memoria al crear columnas (meta)\n\n");
		exit(0);
	}

	// Determinar los nombres de cada columna de datos
	if(header)
	{
		tok=strtok(cabecera, separadores);
		i=0;
		while(tok!=NULL)
		{
			strcpy(ds->meta[i].nombre, tok);
			tok=strtok(NULL, separadores);
			i++;
		}
	}
	else
	{
		for(i=0 ; i<numCol ; i++)
		{
			sprintf(ds->meta[i].nombre, "column_%02", i);
		}
	}

	// Determinar el tipo de cada columna de datos
	tok=strtok(lineaDatos, separadores);
	i=0;
	while(tok!=NULL)
	{
		ds->meta[i].tipo = ObtenerTipo(tok);
		switch(ds->meta[i].tipo)
		{
			case NUM:
				ds->meta[i].min = ds->meta[i].max = ds->meta[i].sum = atof(tok);
				break;
			case LABEL:
				ds->meta[i].numValores=1;
				ds->meta[i].etiquetas=(char**)malloc(sizeof(char*));
				ds->meta[i].etiquetas[0]=strdup(tok);
				ds->meta[i].repeticiones=(int*)malloc(sizeof(int));
				ds->meta[i].repeticiones[0]=1;
				break;
			default:
				printf("ERROR, tipo de dato no reconocido\n\n");
				exit(1);
				break;
		}
		tok=strtok(NULL, separadores);
		i++;
	}

	// Número de columnas, filas de datos y filas erroneas
	ds->nc=numCol;
	ds->nf=1;
	ds->nErr=0;
}

int FilaValida(TDataset *ds, char *lineaDatos, char *separadores, int modo)
{
	int i, pos, numCol= numColumnas(lineaDatos, separadores[0]);
	char **tok;
	double numAux;

	if(modo!=1 && modo!=2)
	{
		printf("ERROR en parametro 'modo' de validar fila (se esperaba 1 o 2)\n\n");
		exit(0);
	}

	if(ds->nc != numCol)
		return 0;

	tok=(char**)malloc(sizeof(char*)*numCol);
	if(tok==NULL)
	{
		printf("ERROR de memoria en validar fila\n\n");
		exit(0);
	}

	// Extraer todos los tokens y ver si son del tipo esperado
	i=0;
	tok[i] = strtok(lineaDatos, separadores);
	while(1)
	{
		if(ds->meta[i].tipo != ObtenerTipo(tok[i]))
		{
			free(tok);
			return 0;
		}

		i++;
		if(i >= numCol)
			break;
		tok[i] = strtok(NULL, separadores);
	}

	// Procesar cada uno de los tokens extraidos
	for(i=0 ; i<numCol ; i++)
	{
		// Segun modo: 1->actualizar METADATOS / 2->actualizar DATOS
		switch(modo)
		{
			case 1: // METADATOS
				switch(ds->meta[i].tipo)
				{
					case NUM:
						numAux = atof(tok[i]);
						if(ds->meta[i].min > numAux)
							ds->meta[i].min = numAux;
						else if(ds->meta[i].max < numAux)
							ds->meta[i].max = numAux;
						ds->meta[i].sum += numAux;
						break;

					case LABEL:
						pos = IndexOfStr(ds->meta[i].etiquetas, ds->meta[i].numValores, tok[i]);
						if(pos==-1)
						{
							ds->meta[i].numValores++;
							ds->meta[i].etiquetas=(char**)realloc(ds->meta[i].etiquetas, (sizeof(char*) * ds->meta[i].numValores));
							ds->meta[i].etiquetas[ds->meta[i].numValores-1]=strdup(tok[i]);
							ds->meta[i].repeticiones=(int*)realloc(ds->meta[i].repeticiones, (sizeof(int) * ds->meta[i].numValores));
							ds->meta[i].repeticiones[ds->meta[i].numValores-1]=1;
						}
						else
						{
							ds->meta[i].repeticiones[pos]++;
						}
						break;
				}
				break;

			case 2: // DATOS
				switch(ds->meta[i].tipo)
				{
					case NUM:
						ds->mat[ds->nf][i] = atof(tok[i]);
						break;

					case LABEL:
						ds->mat[ds->nf][i] = IndexOfStr(ds->meta[i].etiquetas, ds->meta[i].numValores, tok[i]);
						break;
				}
				break;
		}
	}

	free(tok);
	return 1;
}

void dsShuffle(TDataset *ds)
{
	int i, j;
	double *rowAux;

	for(i=0 ; i<ds->nf ; i++)
	{
		j = rand() % ds->nf;

		rowAux = ds->mat[i];
		ds->mat[i] = ds->mat[j];
		ds->mat[j] = rowAux;
	}
}

void dsFree(TDataset *ds)
{
	int i, j;
	
	for(i=0 ; i<ds->nc ; i++)
	{
		for(j=0 ; j<ds->meta[i].numValores ; j++)
			free(ds->meta[i].etiquetas[j]);
		free(ds->meta[i].etiquetas);
		free(ds->meta[i].repeticiones);
	}
	free(ds->meta);
	
	for(i=0 ; i<ds->nf ; i++)
		free(ds->mat[i]);
	free(ds->mat);
	dsInit(ds);
}
