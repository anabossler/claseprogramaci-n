/*
Libreria para crear modelos de reglas de clasificacion
*/

#ifndef __rule_h__
#define __rule_h__

#include"data.h"

typedef struct RULE
{
  // ANTECEDENTE DE LA REGLA
  int nAtributos;    // Tamaño del array de antecedentes
  int *antecedente;  // Array con los valores de antecedente
  int soporte;
  // CONSECUENTE DE LA REGLA
  int nClases;       // Número de valores de clase del antecedente
  int *confianzas;   // Array de confianzas para cada clase

  struct RULE *siguiente; // Puntero para la lista de reglas
}TRule;

typedef struct
{
  // ACCESO AL DATASET
  TDataset *data;      // Referencia al conjunto de datos de entrenamiento
  int idIni, idFin;    // intervalo de registros a usar en el training

  // METADATOS DE LAS REGLAS
  int nAntecedentes;   // Tamaño del array de antecedentes
  int *atributos;      // Array con los IDs de los atributos antecedentes
  int consecuente;     // ID del atributo consecuente

  // CONJUTO (LITA) DE REGLAS
  int n;               // Tamaño del conjunto de reglas
  TRule *primera;      // Primera regla

  // MATRIZ DE CONFUSIÓN
  int nClases;
  int **matrizConfusion;
  int aciertos, fallos;
}TRuleset;

// OPERACIONES SOBRE REGLAS
TRule *RuleCreate(double *row, int *idAntec, int nAntec, int idConseq, int nConseq);
int RuleEqualAntecedent(TRule *r, double *row, int *idAntec, int idConseq);
void RulePrint(TRule *r, int *idAntec, TDataset *data);
void RuleFree(TRule *r);

// OPERACIONES SOBRE EL CONJUNTO DE REGLAS
void rsInit(TRuleset *rs);
int rsSet(TRuleset *rs, TDataset *ds, int *idAntec, int nAntec, int idConseq);
int rsIntuitive(TRuleset *rs, int ini, int fin);
void rsSort(TRuleset *rs);
int rsPredict(TRuleset *rs, double *row);
void rsSetMatrix(TRuleset *rs);
void rsTest(TRuleset *rs, int ini, int fin);
void rsDeleteRules(TRuleset *rs);
void rsFree(TRuleset *rs);
void rsSaveRules(TRuleset *rs, char *nombreFichero);
void rsSaveMatrix(TRuleset *rs, char *nombreFichero);
void rsCrossValidation(TRuleset *rs);

#endif
