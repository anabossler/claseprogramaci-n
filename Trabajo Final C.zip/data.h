/*
Libreria para lectura y carga de datos en memoria desde fichero CSV
*/

#ifndef __data_h__
#define __data_h__

// Definición de los diferentes tipos de datos que se pueden encontrar en un dataset
typedef enum {VOID, NUM, LABEL, DATE, HOUR} TYPE;

// Estructura para los metadatos de una columan del dataset
typedef struct
{
	char nombre[31];
	TYPE tipo;
	double min, max, sum; // valores minimo, maximo y sumatorio de una columna tipo NUM
	int histograma[10];   // para calcular el histograma de 10 segmentos, solo para tipo NUM
	int numValores;       // valores tipo LABEL distintos
	char **etiquetas;     // nombres de cada etiqueta de la columna
	int *repeticiones;    // veces que se repite el valor de cada etiqueta
}TColumn;

typedef struct
{
	// METADATOS
	int nf, nc; // Numero de filas y numero de columnas
	int nErr;   // Numero de filas erroneas
	TColumn *meta;

	// DATOS
	double **mat;
}TDataset;


// PROTOTIPOS 
void dsInit(TDataset *ds);
int  dsLoad(TDataset *ds, const char *fileName, int header, char sep);
int  dsSaveMeta(const TDataset *ds, const char *fileName);
int  dsSaveData(const TDataset *ds, const char *fileName, int header, char sep);
void dsShuffle(TDataset *ds);
void dsFree(TDataset *ds);


int IndexOfStr(char **arr, int n, const char *val);
int numColumnas(char *reg, char sep);
int validarNum(char *cad);
TYPE ObtenerTipo(char *cad);
char *cadenaTipo(TYPE t);
void CrearColumnas(TDataset *ds, char *cabecera, char *lineaDatos, int header, char *separadores);
int FilaValida(TDataset *ds, char *lineaDatos, char *separadores, int modo);
#endif