#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rule.h"

//
// OPERACIONES CON REGLAS
//
TRule *RuleCreate(double *row, int *idAntec, int nAntec, int idConseq, int nConseq)
{
	TRule *r;
	int i;

	if (!(r = (TRule *)malloc(sizeof(TRule))))
	{
		printf("ERROR, fallo de memoria al crear regla (1)\n\n");
		exit(0);
	}
	r->nAtributos = nAntec;
	r->soporte = 1;
	r->nClases = nConseq;
	r->antecedente = (int *)malloc(sizeof(int) * nAntec);
	r->confianzas = (int *)malloc(sizeof(int) * nConseq);
	if (r->antecedente == NULL || r->confianzas == NULL)
	{
		printf("ERROR, fallo de memoria al crear regla (2)\n\n");
		exit(0);
	}

	for (i = 0; i < nAntec; i++)
		r->antecedente[i] = (int)row[idAntec[i]];
	for (i = 0; i < nConseq; i++)
	{
		if (i == (int)row[idConseq])
			r->confianzas[i] = 1;
		else
			r->confianzas[i] = 0;
	}
	return r;
}

int RuleEqualAntecedent(TRule *r, double *row, int *idAntec, int idConseq)
{
	int i;

	for (i = 0; i < r->nAtributos; i++)
		if (r->antecedente[i] != (int)row[idAntec[i]])
			return 0;

	// Actualizar soporte y confianza
	r->soporte++;
	r->confianzas[(int)row[idConseq]]++;

	return 1;
}

void RulePrint(TRule *r, int *idAntec, TDataset *data)
{
	printf("Soporte \t");
	for (int i = 0; i < r->nAtributos; i++)
	{
		printf("%s\t", data->meta[i].nombre);
	}
	printf("=>");

	for(int i = 0; i < r->nClases; i++)
		printf("\t%s\t", data->meta[i].etiquetas[i]);

	printf("\n");
	printf("%d\t", r->soporte);
	for (int i = 0; i <  r->nAtributos; i++)
		printf("\t%s\t", data->meta[idAntec[i]].etiquetas[r->antecedente[i]]);
	for (int i = 0; i < r->nClases; i++)
		printf("\t\t%d", r->confianzas[i]);
	printf("\n\n");
}

void RuleFree(TRule *r)
{
	if (r)
	{
		free(r->antecedente);
		free(r->confianzas);
		free(r);
	}
}

//
// OPERACIONES CON CONJUNTOS (LISTAS) DE REGLAS
//
void rsInit(TRuleset *rs)
{
	rs->data = NULL;
	rs->idIni = rs->idFin = 0;

	rs->nAntecedentes = rs->consecuente = -1;
	rs->atributos = NULL;

	rs->n = 0;
	rs->primera = NULL;

	rs->nClases = 0;
	rs->matrizConfusion = NULL;
	rs->aciertos = rs->fallos = -1;
}

int rsSet(TRuleset *rs, TDataset *ds, int *idAntec, int nAntec, int idConseq)
{
	int i;

	rs->data = ds;
	rs->nAntecedentes = nAntec;
	rs->consecuente = idConseq;
	rs->nClases = ds->meta[idConseq].numValores;
	rs->atributos = (int *)malloc(sizeof(int) * nAntec);

	rs->matrizConfusion = (int **)malloc(sizeof(int *) * rs->nClases);

	if (rs->atributos == NULL || rs->matrizConfusion == NULL)
	{
		printf("ERROR de mamoria en rsSet\n\n");
		exit(1);
	}
	for (i = 0; i < nAntec; i++)
		rs->atributos[i] = idAntec[i];
	for (i = 0; i < rs->nClases; i++)
	{
		rs->matrizConfusion[i] = (int *)malloc(sizeof(int) * rs->nClases);
		if (rs->matrizConfusion[i] == NULL)
		{
			printf("ERROR de mamoria en rsSet\n\n");
			exit(1);
		}
	}
	return 1;
}

int rsIntuitive(TRuleset *rs, int ini, int fin)
{
	int f, c, test;
	TRule *r, *rAux;

	if (ini < 0 || fin < 0)
	{
		ini = 0;
		fin = rs->data->nf - 1;
	}

	rs->idIni = ini;
	rs->idFin = fin;

	for (f = ini; f <= fin; f++)
	{
		r = rs->primera;
		while (r != NULL)
		{
			if (RuleEqualAntecedent(r, rs->data->mat[f], rs->atributos, rs->consecuente))
				break;
			r = r->siguiente;
		}
		if (r == NULL)
		{
			rAux = RuleCreate(rs->data->mat[f], rs->atributos, rs->nAntecedentes, rs->consecuente, rs->nClases);

			rAux->siguiente = rs->primera;
			rs->primera = rAux;
			rs->n++;
		}
	}
	rsSort(rs);
	return 1;
}

void rsSort(TRuleset *rs)
{
	TRule *i, *j, *max;
	int num, *vec;

	if (rs == NULL || rs->n <= 1)
		return;

	i = rs->primera;
	while (i->siguiente != NULL)
	{
		max = i;
		j = i->siguiente;
		while (j != NULL)
		{
			if (j->soporte > max->soporte)
				max = j;
			j = j->siguiente;
		}
		if (max != i) // SWAP (intercambi)
		{
			num = max->nAtributos;
			max->nAtributos = i->nAtributos;
			i->nAtributos = num;

			vec = max->antecedente;
			max->antecedente = i->antecedente;
			i->antecedente = vec;

			num = max->soporte;
			max->soporte = i->soporte;
			i->soporte = num;

			num = max->nClases;
			max->nClases = i->nClases;
			i->nClases = num;

			vec = max->confianzas;
			max->confianzas = i->confianzas;
			i->confianzas = vec;
		}
		i = i->siguiente;
	}
}

int rsPredict(TRuleset *rs, double *row)
{
	TRule *r, *rBest;
	int i, iBest, cont, contBest;

	r = rs->primera;
	rBest = rs->primera;
	contBest = 0;
	while (r != NULL)
	{
		cont = 0;
		for (i = 0; i < rs->nAntecedentes; i++)
			if (r->antecedente[i] == (int)row[rs->atributos[i]])
				cont++;
		if (cont > contBest || (cont == contBest && r->soporte > rBest->soporte))
		{
			contBest = cont;
			rBest = r;
		}
		r = r->siguiente;
	}
	iBest = 0;
	for (i = 0; i < rs->nClases; i++)
		if (rBest->confianzas[i] > rBest->confianzas[iBest])
			iBest = i;
	return iBest;
}

void rsSetMatrix(TRuleset *rs)
{
	int i, j;

	for (i = 0; i < rs->nClases; i++)
		for (j = 0; j < rs->nClases; j++)
			rs->matrizConfusion[i][j] = 0;

	rs->aciertos = rs->fallos = 0;
}

void rsTest(TRuleset *rs, int ini, int fin)
{
	int i, res;

	for (i = ini; i <= fin; i++)
	{
		res = rsPredict(rs, rs->data->mat[i]);
		rs->matrizConfusion[(int)rs->data->mat[i][rs->consecuente]][res]++;
		if ((int)rs->data->mat[i][rs->consecuente] == res)
			rs->aciertos++;
		else
			rs->fallos++;
	}
}

void rsDeleteRules(TRuleset *rs)
{
	TRule *rAux;

	while (rs->primera != NULL)
	{
		rAux = rs->primera;
		rs->primera = rs->primera->siguiente;
		RuleFree(rAux);
	}
	rs->n = 0;
	rs->primera = NULL;
}

void rsFree(TRuleset *rs)
{
	int i;

	free(rs->atributos);
	rsDeleteRules(rs);

	for (i = 0; i < rs->nClases; i++)
		free(rs->matrizConfusion[i]);
	free(rs->matrizConfusion);
	rsInit(rs);
}


void rsSaveRules(TRuleset *rs, char *nombreFichero)
{
	TRule *r = rs->primera;
	FILE *f = fopen(nombreFichero, "w");

	if (f == NULL)
	{
		printf("Error al abrir el fichero\n");
		return;
	}

	fprintf(f, "Soporte\t");
	for (int i = 0; i < r->nAtributos; i++)
	{
		fprintf(f, "%s\t", rs->data->meta[rs->atributos[i]].nombre);
	}

	fprintf(f, "=>");

	for(int i = 0; i < rs->nClases; i++)
		fprintf(f, "\t\t%s\t", rs->data->meta[rs->consecuente].etiquetas[i]);

	while (r != NULL)
	{
		fprintf(f, "\n");
		fprintf(f, "%d\t", r->soporte);

		for (int i = 0; i < r->nAtributos; i++)
		{
			fprintf(f, "\t%s\t\t", rs->data->meta[rs->atributos[i]].etiquetas[r->antecedente[i]]);
		}

		fprintf(f, "\t=>");

		for (int i = 0; i < r->nClases; i++)
		{
			fprintf(f, "\t\t%d\t", r->confianzas[i]);
		}
		r = r->siguiente;
	}

	fprintf(f, "\n\n");
	fprintf(f, "Total de reglas: %d", rs->n);

	fclose(f);
}

void rsSaveMatrix(TRuleset *rs, char *nombreFichero)
{
	FILE *file = fopen(nombreFichero, "w");

	if (file == NULL)
	{
		printf("Error al abrir el fichero\n\n");
		exit(1);
	}
	fprintf(file, "*************************************\n");
	fprintf(file, "******** Matriz de Confusión ********\n");
	fprintf(file, "*************************************\n");

	fprintf(file, "\n");

	for(int i = 0; i < rs->nClases; i++)
		fprintf(file, "\t\t%s", rs->data->meta[rs->consecuente].etiquetas[i]);

	fprintf(file, "\n");
	
	for (int i = 0; i < rs->nClases; i++)
	{
		fprintf(file, "%s", rs->data->meta[rs->consecuente].etiquetas[i]);
		for (int j = 0; j < rs->nClases; j++)
		{
			fprintf(file, "\t%6d", rs->matrizConfusion[i][j]);
		}
		fprintf(file, "\n");
	}

	fprintf(file, "\n");
	fprintf(file, "Aciertos: \t%d\n", rs->aciertos);
	fprintf(file, "Fallos: \t%d\n", rs->fallos);
	fprintf(file, "Precisión: \t%f\n", (float)rs->aciertos / (rs->aciertos + rs->fallos));
	fprintf(file, "*************************************\n");

	fclose(file);
}

void rsCrossValidation(TRuleset *rs){
	int i, ini, fin, segmento = rs->data->nf / 10;

	for(int i = 0 ; i<10 ; i++)
	{
		ini = segmento*(i+1);
		fin = segmento*i - 1;

		if(i==9)
			ini+= rs->data->nf % 10;

		rsIntuitive(rs, 0, fin);
		rsIntuitive(rs, ini, rs->data->nf-1);

		printf("\nInicio: %d \t Final: %d Iteracion: %d\n", ini, fin, i);
		
		rsTest(rs, fin+1, ini-1);
		rsDeleteRules(rs);
	}

	printf("\n");
	printf("Aciertos: %d\n", rs->aciertos);
	printf("Fallos: %d\n", rs->fallos);
	printf("Precision: %f\n", (float)rs->aciertos / (rs->aciertos + rs->fallos));
}